gcc -shared -fPIC -o mon_hook.so mon_hook.c -ldl
